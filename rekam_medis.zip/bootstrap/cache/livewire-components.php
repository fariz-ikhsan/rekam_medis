<?php return array (
  'data-pasien-controller' => 'App\\Http\\Livewire\\DataPasienController',
);