
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="content">
    <?php echo $__env->make('components.modal.select_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('components.modal.create_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('components.modal.edit_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('components.modal.delete_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- BEGIN: Top Bar -->
    <div class="top-bar">
        <!-- BEGIN: Breadcrumb -->
        <div class="-intro-x breadcrumb mr-auto hidden sm:flex"> </div>
        <!-- END: Breadcrumb -->
        <!-- BEGIN: Account Menu -->
       <?php echo $__env->make('components.account_dropdown', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END: Account Menu -->
    </div>
    <!-- END: Top Bar -->
    <h2 class="text-lg font-medium mr-auto" style="font-size: 30px;">
        Daftar Data Kunjungan Pasien
    </h2>
    <div class="grid grid-cols-12 gap-6 mt-5">
        <div class="intro-y col-span-12 flex flex-wrap sm:flex-no-wrap items-center mt-2">
            <div class="hidden md:block mx-auto text-gray-600"></div>
            <div class="w-full sm:w-auto mt-3 sm:mt-0 sm:ml-auto md:ml-0">
                <div class="w-56 relative text-gray-700 dark:text-gray-300">
                    <input id="cariInput" name="cari" type="text" class="input w-56 box pr-10 placeholder-theme-13" placeholder="Search..." onfocus="this.value=''">
                    <i class="w-4 h-4 absolute my-auto inset-y-0 mr-3 right-0" data-feather="search"></i> 
                </div>
            </div>
        </div>
        <!-- BEGIN: Data List -->
        <script>
            var routeInitial = "vitalsign";
        </script>
        <div id="tableBase" class="intro-y col-span-12 overflow-auto lg:overflow-visible">
            <table class="table table-report -mt-2">
                <thead>
                    <tr>
                        <th class="whitespace-no-wrap" style="display:none;">id_pendaftaran</th>
                        <th class="whitespace-no-wrap">No RM</th>
                        <th class="whitespace-no-wrap">Nama</th>
                        <th class="whitespace-no-wrap">Dokter</th>
                        <th class="whitespace-no-wrap">Ruangan</th>
                        <th class="text-center whitespace-no-wrap">OPSI</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="intro-x">
                            <td id="idpendaftaran" style="display:none;">
                                <?php echo e($item->no_rekmed); ?>

                            </td>
                            <td class="font-medium whitespace-no-wrap">
                                <?php echo e($item->no_rekmed); ?>

                            </td>
                            <td class="font-medium whitespace-no-wrap">
                                <?php echo e($item->nama); ?>

                            </td>
                            <td class="font-medium whitespace-no-wrap">
                                <?php $__currentLoopData = $namadokter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noRekmed => $doctors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($noRekmed == $item->no_rekmed): ?>
                                        <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($doctor); ?>

                                            <?php if(!$loop->last): ?>
                                                <?php echo e(', '); ?>

                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td class="font-medium whitespace-no-wrap">
                                <?php $__currentLoopData = $ruangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noRekmed => $ruangann): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($noRekmed == $item->no_rekmed): ?>
                                        <?php $__currentLoopData = $ruangann; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lokasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($lokasi); ?>

                                            <?php if(!$loop->last): ?>
                                                <?php echo e(', '); ?>

                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td>
                                <div class="flex justify-center items-center">
                                    <a class="flex items-center text-theme-1 mr-3" onclick="selectBtnOnclick(<?php echo e($index); ?>, 'suster')" href="javascript:;" data-toggle="modal" data-target="#selectmodal">
                                        <i data-feather="check-square" class="w-4 h-4 mr-1"></i> Pilih
                                    </a>
                                </div>
                                <script>
                                    $("#executeSelectBtnOnclick").on("click", function () {
                                        var berat_badan = $("input[name='berat_badan']").val();
                                        var tekanan_darah = $("input[name='tekanan_darah']").val();

                                        $("#selectContentBase input:gt(1)").each(function () {
                                            if ($(this).val() === "") {
                                                // Fill it with a default value
                                                $(this).val("-");
                                            }
                                        });
                                        if (berat_badan === "" || tekanan_darah === "") {
                                            if (berat_badan === "") {
                                                alert("Berat badan wajib diisi!");
                                            } else if (tekanan_darah === "") {
                                                alert("Tekanan darah wajib diisi!");
                                            }
                                        } else {
                                            $("#selectForm").submit();
                                        }
                                    });
                                </script>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo $__env->make('components.pagination', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <?php echo $__env->make('components.modal.configuration_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END: Data List -->
        <!-- BEGIN: Pagination -->
       
        <!-- END: Pagination -->
    </div>
</div>
<script>
    $(document).ready(function() {
        // Define the function to handle the AJAX request
        function performSearch(query) {
            $.ajax({
                url: routeInitial,
                type: "GET",
                data: { 'searchdata': query, },
                success: function(data) {
                    $("#tableBase").html(data);
                    
   
                }
            });
        }
        $(document).on('click', '#pagination-container a', function(event){
            event.preventDefault(); 
            var page = $(this).attr('href').split('page=')[1];
            $.ajax({
                url:window.location.href+"?page="+page,
                    success:function(data)
                    {
                        $('#tableBase').html(data);
                    }
                });
            });
        

        // Set up the keyup event handler
        $('#cariInput').keyup(function() {
            var query = $(this).val();
            performSearch(query);
        });
    });
</script>


<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\rekam_medis\resources\views/contents/transaksi/data_vital_sign.blade.php ENDPATH**/ ?>