<!-- resources/views/dokter.blade.php -->


<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div onclick="selectDokter(<?php echo e($index); ?>, '<?php echo e($item->id_jdwdokter); ?>')" class="intro-y col-span-6 sm:col-span-4 md:col-span-3 xxl:col-span-2" style="width: 50%; height: 50%;">
        <div class="file box rounded-md px-5 pt-8 pb-5 px-3 sm:px-5 relative zoom-in">
            <div id="dktImageDivPdf">
                <img id="tbImage_<?php echo e($index); ?>" src="<?php echo e($item->photo); ?>" class="rounded-full">
            </div>
            <div class="block font-medium mt-4 text-center truncate"><?php echo e($item->nama); ?></div>
            <div class="text-gray-600 text-xs text-center"><?php echo e($item->poli); ?></div>
            <div class="text-gray-600 text-xs text-center"><?php echo e($item->lokasi); ?></div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<script>
    var idjdwdokter = "";
    function selectDokter(index, idjadwaldokter) {
        $("#caridokterRujukan > div > div").each(function() {
            $(this).css("background-color", "");
        });

        $("#caridokterRujukan > div").eq(index).find("> div").css("background-color", "cornsilk");
        idjdwdokter = idjadwaldokter;
        alert(idjdwdokter)
    }

    


</script>
<?php /**PATH E:\xampp\htdocs\rekam_medis\resources\views/contents/search/search_rujukan_dokter.blade.php ENDPATH**/ ?>