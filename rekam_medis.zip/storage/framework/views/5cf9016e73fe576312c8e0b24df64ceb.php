<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access-admin')): ?>
    <?php echo $__env->make('layouts.sidebars.admin_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access-dokter')): ?>
    <?php echo $__env->make('layouts.sidebars.spesialistik_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?><?php /**PATH E:\xampp\htdocs\rekam_medis\resources\views/layouts/sidebars/master_sidebar.blade.php ENDPATH**/ ?>