       </div>
        <!-- BEGIN: JS Assets-->
        <script src="https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/markerclusterer.js"></script>
        <script src="https://maps.googleapis.com/maps/api/js?key=["your-google-map-api"]&libraries=places"></script>
        <script src="<?php echo e(asset('dist/js/app.js')); ?>"></script>
        <!-- END: JS Assets-->
    </body>
</html><?php /**PATH E:\xampp\htdocs\rekam_medis\resources\views/layouts/footer.blade.php ENDPATH**/ ?>