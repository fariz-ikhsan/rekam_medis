<div id="pagination-container">
    <?php echo $data->links(); ?>

</div><?php /**PATH E:\xampp\htdocs\rekam_medis\resources\views/components/pagination.blade.php ENDPATH**/ ?>