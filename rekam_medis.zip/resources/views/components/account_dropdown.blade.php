<div class="intro-x dropdown">
    <form action="/logout" method="GET">
        @csrf
        <button type="submit" class="button rounded-full mr-1 mb-2 flex items-center justify-center bg-theme-6 text-white">Keluar <i data-feather="log-out" style="margin-left: 6px;"></i></button> 
    </form>
</div>