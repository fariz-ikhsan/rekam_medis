<div class="modal" id="delete-modal-preview">
    <div class="modal__content">
        <div class="p-5 text-center"> <i data-feather="x-circle" class="w-16 h-16 text-theme-6 mx-auto mt-3"></i>
            <div class="text-3xl mt-5">PERINGATAN PENTING!</div>
            <h5 class="text-xl font-medium leading-none mt-3">Data yang dimanipulasi akan permanen tersimpan!</h5>
            <h5 class="text-l font-medium leading-none mt-3">Pilih Batal Jika Tidak Ingin ini Terjadi</h5>
        </div>
        <div class="px-5 pb-8 text-center"> <button type="button" data-dismiss="modal" class="button w-24 border text-gray-700 dark:border-dark-5 dark:text-gray-300 mr-1">Batal</button> <button onclick="setujumanipulasirm()" type="button" class="button w-24 bg-theme-6 text-white">SETUJU</button> </div>
    </div>
</div>