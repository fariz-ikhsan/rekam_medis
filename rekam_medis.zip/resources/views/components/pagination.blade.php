<div id="pagination-container">
    {!! $data->links() !!}
</div>